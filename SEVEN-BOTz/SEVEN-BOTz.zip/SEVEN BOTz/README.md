## <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Hi.gif" width="29px"> I'm Arnando
<p align="center">
<img src="https://raw.githubusercontent.com/Arnando456/REM/main/assets/Arnando.jpg" width="230" height="230"/>
</p>
<br>



<p align="center">
<a href="#"><img title="Sad Boy" src="https://img.shields.io/badge/ARNANDO-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/Arnando456"><img title="Author" src="https://img.shields.io/badge/AUTHOR-ARNANDO-orange.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/Arnando456/Rem/followers"><img title="Followers" src="https://img.shields.io/github/followers/Arnando456?color=blue&style=flat-square"></a>
<a href="https://github.com/Arnando456/Rem/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Arnando456/REMcolor=red&style=flat-square"></a>
<a href="https://github.com/Arnando456/Rem/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Arnando456/REM?color=red&style=flat-square"></a>
<a href="https://github.com/Arnando456/Rem/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Arnando456/REM?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FArnando456%2FREM&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2300FF6D&title=hits&edge_flat=false"/></a>
</p>
<img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Developer.gif" alt="Mario Game" width="600" />
<div align="center">
<details>
 
</details>

## Clone this project

```bash
> git clone https://github.com/Arnando456/Rem
```

## Install the dependencies:
Before running the below command, make sure you're in the project directory that
you've just cloned!!

```bash
> cd REM
> bash install.sh
```

### Usage
```bash
> npm start
```



## SOSIAL MEDIA ADMIN <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/powerup.gif" width="29px">

* [`Youtube Admin`](https://youtube.com/channel/UCal0HWOurq6GIF4_z0N2B6Q)
* [`WhatsApp Admin `](https://wa.me/+6281534162316)
* [`Group WhatsApp `](https://chat.whatsapp.com/Eb4niW86N3kHbMjgmdL4WU)
## THANKS TO <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Handshake.gif" width="60px">

* [`ALLAH SWT`]
<img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Mario_Gameplay.gif" alt="Mario Game" width="600" />

